{
 "cells": [
  {
   "cell_type": "code",
   "execution_count": 3,
   "id": "2a7b58db",
   "metadata": {},
   "outputs": [
    {
     "data": {
      "text/plain": [
       "-5"
      ]
     },
     "execution_count": 3,
     "metadata": {},
     "output_type": "execute_result"
    }
   ],
   "source": [
    "9//-2"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 4,
   "id": "507b9109",
   "metadata": {},
   "outputs": [
    {
     "data": {
      "text/plain": [
       "1.0"
      ]
     },
     "execution_count": 4,
     "metadata": {},
     "output_type": "execute_result"
    }
   ],
   "source": [
    "9.0%2"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 5,
   "id": "3c120d04",
   "metadata": {},
   "outputs": [
    {
     "data": {
      "text/plain": [
       "1.0"
      ]
     },
     "execution_count": 5,
     "metadata": {},
     "output_type": "execute_result"
    }
   ],
   "source": [
    "9%2.0"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 6,
   "id": "b3fc6785",
   "metadata": {},
   "outputs": [
    {
     "data": {
      "text/plain": [
       "-1"
      ]
     },
     "execution_count": 6,
     "metadata": {},
     "output_type": "execute_result"
    }
   ],
   "source": [
    "9%-2"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 7,
   "id": "01a06822",
   "metadata": {},
   "outputs": [
    {
     "data": {
      "text/plain": [
       "1"
      ]
     },
     "execution_count": 7,
     "metadata": {},
     "output_type": "execute_result"
    }
   ],
   "source": [
    "-9%2"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 8,
   "id": "105c2366",
   "metadata": {},
   "outputs": [
    {
     "data": {
      "text/plain": [
       "-1.0"
      ]
     },
     "execution_count": 8,
     "metadata": {},
     "output_type": "execute_result"
    }
   ],
   "source": [
    "9%-2.0"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 9,
   "id": "536c67cc",
   "metadata": {},
   "outputs": [
    {
     "data": {
      "text/plain": [
       "19"
      ]
     },
     "execution_count": 9,
     "metadata": {},
     "output_type": "execute_result"
    }
   ],
   "source": [
    "4+3*5"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 10,
   "id": "ef911e45",
   "metadata": {},
   "outputs": [
    {
     "data": {
      "text/plain": [
       "35"
      ]
     },
     "execution_count": 10,
     "metadata": {},
     "output_type": "execute_result"
    }
   ],
   "source": [
    "(4+3)*5"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 14,
   "id": "8d24f857",
   "metadata": {},
   "outputs": [
    {
     "data": {
      "text/plain": [
       "78.5"
      ]
     },
     "execution_count": 14,
     "metadata": {},
     "output_type": "execute_result"
    }
   ],
   "source": [
    "pi=3.14;\n",
    "r=5\n",
    "area_circle=pi*(r**2)\n",
    "area_circle"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 24,
   "id": "94cefefe",
   "metadata": {},
   "outputs": [
    {
     "name": "stdout",
     "output_type": "stream",
     "text": [
      "Enter a number:5\n",
      "5  <class 'int'>\n"
     ]
    }
   ],
   "source": [
    "num=int(input(\"Enter a number:\"))\n",
    "print(num, \"\", type(num))\n",
    "      "
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 30,
   "id": "4dba8116",
   "metadata": {},
   "outputs": [
    {
     "name": "stdout",
     "output_type": "stream",
     "text": [
      "Enter a number2\n",
      "Enter a number24\n",
      "sum is 6\n",
      "product is 8\n",
      "diffrence is -2\n",
      "quotient is 0.5\n"
     ]
    }
   ],
   "source": [
    "\n",
    "num1=int(input(\"Enter a number\"))\n",
    "num2=int(input(\"Enter a number2\"))\n",
    "print(\"sum is\",num1+num2)\n",
    "print(\"product is\",num1*num2)\n",
    "print(\"diffrence is\",num1-num2)\n",
    "print(\"quotient is\",num1/num2)"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 39,
   "id": "412f851f",
   "metadata": {},
   "outputs": [
    {
     "name": "stdout",
     "output_type": "stream",
     "text": [
      "HHHHH\n",
      "HHHH\n",
      "HHH\n",
      "HH\n",
      "H\n"
     ]
    }
   ],
   "source": [
    "var=\"H\"\n",
    "print(var*5)\n",
    "print(\"\"+var*4)\n",
    "print(\"\"+var*3)\n",
    "print(\"\"+var*2)\n",
    "print(\"\"+var*1)"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 40,
   "id": "a5ed4f62",
   "metadata": {},
   "outputs": [
    {
     "data": {
      "text/plain": [
       "False"
      ]
     },
     "execution_count": 40,
     "metadata": {},
     "output_type": "execute_result"
    }
   ],
   "source": [
    "5!=5"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 41,
   "id": "b74517a8",
   "metadata": {},
   "outputs": [
    {
     "data": {
      "text/plain": [
       "True"
      ]
     },
     "execution_count": 41,
     "metadata": {},
     "output_type": "execute_result"
    }
   ],
   "source": [
    "\"hello\"==\"hello\""
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 47,
   "id": "8feb2962",
   "metadata": {},
   "outputs": [
    {
     "name": "stdout",
     "output_type": "stream",
     "text": [
      "true\n"
     ]
    }
   ],
   "source": [
    "num=10\n",
    "if num==10:\n",
    "    print(\"true\")\n",
    "else:\n",
    "    print(\"false\")\n",
    "\n",
    "   \n",
    "   \n",
    "    "
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 49,
   "id": "a25b5791",
   "metadata": {},
   "outputs": [
    {
     "name": "stdout",
     "output_type": "stream",
     "text": [
      "Even\n"
     ]
    }
   ],
   "source": [
    "num=10\n",
    "if num%2==0:\n",
    "    print(\"Even\")\n",
    "else:\n",
    "    print(\"Odd\")"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 71,
   "id": "41928346",
   "metadata": {},
   "outputs": [
    {
     "name": "stdout",
     "output_type": "stream",
     "text": [
      "smallest is 2\n"
     ]
    }
   ],
   "source": [
    "# x=int(input(\"Enter a number1\"))\n",
    "# y=int(input(\"Enter a number2\"))\n",
    "# z=int(input(\"Enter a number3\"))\n",
    "num1=2\n",
    "num2=4\n",
    "num3=5\n",
    "if num1 < num2 and num1 < num3 :\n",
    "      print(\"smallest is\",num1)\n",
    "elif num2 < num1 and num2 < num3 :\n",
    "          print(\"smallest is\",num2) \n",
    "else:\n",
    "        print(\"smallest is\",num3)\n",
    "\n"
   ]
  }
 ],
 "metadata": {
  "kernelspec": {
   "display_name": "Python 3 (ipykernel)",
   "language": "python",
   "name": "python3"
  },
  "language_info": {
   "codemirror_mode": {
    "name": "ipython",
    "version": 3
   },
   "file_extension": ".py",
   "mimetype": "text/x-python",
   "name": "python",
   "nbconvert_exporter": "python",
   "pygments_lexer": "ipython3",
   "version": "3.10.9"
  }
 },
 "nbformat": 4,
 "nbformat_minor": 5
}
