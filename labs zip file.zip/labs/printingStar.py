#!/usr/bin/env python
# coding: utf-8

# In[2]:


print("*")
print("**")
print("***")
print("****")
print("*****")


# In[ ]:




